package com.example.mobdeves19mcogr4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CafeDetailsActivity extends AppCompatActivity {

    private TextView nameTextView;
    private TextView locationTextView;
    private TextView descriptionTextView;
    private ImageView cafeImageView;
    private TextView wifiTextView;
    private TextView quietTextView;
    private TextView groupTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe_details);

        // Initialize views
        nameTextView = findViewById(R.id.cafeNameTextView);
        locationTextView = findViewById(R.id.cafeLocationTextView);
        descriptionTextView = findViewById(R.id.cafeDescriptionTextView);
        cafeImageView = findViewById(R.id.cafeImageView);
        wifiTextView = findViewById(R.id.wifiTextView);
        quietTextView = findViewById(R.id.quietTextView);
        groupTextView = findViewById(R.id.groupTextView);

        // Get the intent and extract the cafe details
        Intent intent = getIntent();
        String cafeName = intent.getStringExtra("cafeName");
        String cafeLocation = intent.getStringExtra("cafeLocation");
        String cafeDescription = intent.getStringExtra("cafeDescription");
        String cafeImageName = intent.getStringExtra("cafeImageName"); // Change to cafeImageName
        boolean hasWifi = intent.getBooleanExtra("cafeHasWifi", false);
        boolean isQuiet = intent.getBooleanExtra("cafeIsQuiet", false);
        boolean isGroup = intent.getBooleanExtra("cafeIsGroup", false);

        // Set the extracted details to the UI components
        nameTextView.setText(cafeName);
        locationTextView.setText(cafeLocation);
        descriptionTextView.setText(cafeDescription);

        // Load the cafe image from drawable
        int imageResId = getResources().getIdentifier(cafeImageName, "drawable", getPackageName());
        cafeImageView.setImageResource(imageResId); // Set image resource directly

        wifiTextView.setText(hasWifi ? "Wifi Available" : "No Wifi");
        quietTextView.setText(isQuiet ? "Quiet Atmosphere" : "Not Quiet");
        groupTextView.setText(isGroup ? "Group-Friendly" : "Not Group-Friendly");
    }
}