package com.example.mobdeves19mcogr4;

import android.content.Intent; // Import Intent class
import android.os.Bundle;
import android.view.View; // Import View class
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Find the register button by its ID
        Button submitRegisterButton = findViewById(R.id.submitRegisterButton);

        // Set an OnClickListener for the button
        submitRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start LoginActivity
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                // Optionally finish this activity if you don't want to return to it
                finish();
            }
        });
    }
}
