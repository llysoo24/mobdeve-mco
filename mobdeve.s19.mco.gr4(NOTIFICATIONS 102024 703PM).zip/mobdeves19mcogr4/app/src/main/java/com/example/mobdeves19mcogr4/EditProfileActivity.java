package com.example.mobdeves19mcogr4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    private EditText nameEditText;
    private EditText bioEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        // Initialize UI components
        nameEditText = findViewById(R.id.nameEditText);
        bioEditText = findViewById(R.id.bioEditText);
        saveButton = findViewById(R.id.saveButton);

        // Retrieve the current profile data and populate the EditText fields (You may need to pass this data through Intent extras)
        // For simplicity, let's use hardcoded values
        nameEditText.setText("Jake");
        bioEditText.setText("Trying and rating coffee shops so you don't have to");

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle saving of updated data (e.g., saving to a database or shared preferences)
                String updatedName = nameEditText.getText().toString();
                String updatedEmail = bioEditText.getText().toString();

                // Return to ViewProfileActivity with the updated data (you can use Intent extras if needed)
                // For now, we'll just finish this activity
                finish();
            }
        });
    }
}
