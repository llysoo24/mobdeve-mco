package com.example.mobdeves19mcogr4;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView cafeRecyclerView;
    private CafeAdapter cafeAdapter;
    private List<Cafe> bgcCafes;
    private List<Cafe> filteredCafes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        cafeRecyclerView = findViewById(R.id.nearbyCafesRecycler);
        cafeRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        Button notificationButton = findViewById(R.id.notificationBtn);
        Button mapViewButton = findViewById(R.id.mapViewBtn);
        SharedPreferences sharedPreferences = getSharedPreferences("CafeFavorites", Context.MODE_PRIVATE);

        bgcCafes = new ArrayList<>();
        bgcCafes.add(new Cafe("Elephant Grounds Manila", "L/G One Bonifacio High Street Mall, BGC, Taguig City, Metro Manila", "₱₱",
                "MON - THURS: 08:00 AM - 11:00PM FRI - SAT: 07:00 AM - 12:00AM SUN: 08:00AM - 12:00AM",
                "0999 887 1407", true, true, true, sharedPreferences.getBoolean("Elephant Grounds Manila", false),
                R.drawable.cafe_image_1));

        bgcCafes.add(new Cafe("Harlan + Holden Coffee (Because Coffee)", "5th Ave, Taguig, Metro Manila", "₱",
                "MON - SUN: 07:00 AM - 10:00PM",
                "0956 513 8877", false, false, true, sharedPreferences.getBoolean("Harlan + Holden Coffee (Because Coffee)", false),
                R.drawable.cafe_image_2));

        bgcCafes.add(new Cafe("Caffe Pocofino", "BGC Corporate Center 2 30th Street, Corner 5th Ave, Taguig, Metro Manila", "₱",
                "24 HOURS",
                "0919 070 3000", false, true, true, sharedPreferences.getBoolean("Caffe Pocofino", false),
                R.drawable.cafe_image_3));


        filteredCafes = new ArrayList<>(bgcCafes);
        cafeAdapter = new CafeAdapter(this, filteredCafes);
        cafeRecyclerView.setAdapter(cafeAdapter);

        ImageButton filterButton = findViewById(R.id.filterButton);
        filterButton.setOnClickListener(v -> showFilterPopup(v));

        Button viewProfileButton = findViewById(R.id.viewProfileBtn);

        viewProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user data from Intent
                Intent intent = getIntent();
                String userName = intent.getStringExtra("USER_NAME");
                String userEmail = intent.getStringExtra("USER_EMAIL");

                // Pass data to ViewProfileActivity
                Intent profileIntent = new Intent(HomeActivity.this, ViewProfileActivity.class);
                profileIntent.putExtra("USER_NAME", userName);
                profileIntent.putExtra("USER_EMAIL", userEmail);
                startActivity(profileIntent);
            }
        });
        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, NotificationActivity.class);
                startActivity(intent);
            }
        });
        Button mapButton = findViewById(R.id.mapViewBtn);
        mapButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, MapActivity.class);
            startActivity(intent);
        });

    }

    private void showFilterPopup(View v) {
        PopupMenu popupMenu = new PopupMenu(this, v);
        popupMenu.getMenuInflater().inflate(R.menu.filter_menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.filter_wifi) {
                applyFilter(true, false, false);
                return true;
            } else if (item.getItemId() == R.id.filter_quiet) {
                applyFilter(false, true, false);
                return true;
            } else if (item.getItemId() == R.id.filter_group) {
                applyFilter(false, false, true);
                return true;
            } else if (item.getItemId() == R.id.filter_all) {
                resetFilters();
                return true;
            } else {
                return false;
            }

        });
        popupMenu.show();
    }

    private void applyFilter(boolean hasWifi, boolean isQuiet, boolean isGroup) {
        filteredCafes.clear();
        for (Cafe cafe : bgcCafes) {
            if ((hasWifi && cafe.hasWifi()) || (isQuiet && cafe.isQuiet()) || (isGroup && cafe.isGroup())) {
                filteredCafes.add(cafe);
            }
        }
        cafeAdapter.notifyDataSetChanged();
        Toast.makeText(this, "Filters applied", Toast.LENGTH_SHORT).show();
    }

    private void resetFilters() {
        filteredCafes.clear();
        filteredCafes.addAll(bgcCafes);
        cafeAdapter.notifyDataSetChanged();
        Toast.makeText(this, "Showing all cafes", Toast.LENGTH_SHORT).show();
    }
}