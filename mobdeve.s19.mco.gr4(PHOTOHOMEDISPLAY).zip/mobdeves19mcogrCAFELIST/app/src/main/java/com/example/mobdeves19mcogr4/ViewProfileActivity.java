package com.example.mobdeves19mcogr4;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ViewProfileActivity extends AppCompatActivity {

    private TextView nameTextView;
    private TextView emailTextView;
    private Button editProfileButton;
    private RecyclerView favoriteCafesRecyclerView;
    private CafeAdapter favoriteCafesAdapter;
    private List<Cafe> favoriteCafes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        // Set up RecyclerView
        favoriteCafesRecyclerView = findViewById(R.id.favoriteCafesRecyclerView);
        favoriteCafesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        favoriteCafes = new ArrayList<>();
        // Load favorite cafes from SharedPreferences
        loadFavoriteCafes();

        // Set up adapter
        favoriteCafesAdapter = new CafeAdapter(this, favoriteCafes);
        favoriteCafesRecyclerView.setAdapter(favoriteCafesAdapter);

        nameTextView = findViewById(R.id.nameTextView);
        emailTextView = findViewById(R.id.emailTextView);
        editProfileButton = findViewById(R.id.editProfileButton);

        Intent intent = getIntent();
        String userName = intent.getStringExtra("USER_NAME");
        String userEmail = intent.getStringExtra("USER_EMAIL");

        nameTextView.setText(userName);
        emailTextView.setText(userEmail);

        editProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("ProfileActivity", "Edit Profile button clicked!");
                Intent intent = new Intent(ViewProfileActivity.this, EditProfileActivity.class);
                startActivity(intent);
            }
        });

    }
    private void loadFavoriteCafes() {
        SharedPreferences sharedPreferences = getSharedPreferences("CafeFavorites", Context.MODE_PRIVATE);
        Set<String> favoriteCafePlaceIds = sharedPreferences.getStringSet("favoriteCafes", new HashSet<>());

        favoriteCafes.clear();
        favoriteCafes = new ArrayList<>();
        for (String placeId : favoriteCafePlaceIds) {
            // Use the placeId to fetch full details of the cafe (you could retrieve these from a predefined list or database)
            Cafe cafe = getCafeByPlaceId(placeId);
            if (cafe != null) {
                favoriteCafes.add(cafe);
            }
        }
    }
    private Cafe getCafeByPlaceId(String placeId) {
        // You could use a local database or predefined list of cafes
        // For now, we'll return a placeholder cafe (make sure to replace this logic as needed)
        return new Cafe("Cafe Name", "Cafe Location", "Open", "Image URL", placeId);
    }
}
