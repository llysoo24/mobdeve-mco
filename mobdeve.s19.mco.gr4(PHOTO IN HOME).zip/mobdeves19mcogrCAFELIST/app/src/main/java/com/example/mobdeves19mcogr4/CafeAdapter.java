package com.example.mobdeves19mcogr4;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CafeAdapter extends RecyclerView.Adapter<CafeAdapter.CafeViewHolder> {
    private final Context context;
    private final List<Cafe> cafes;

    // Constructor
    public CafeAdapter(Context context, List<Cafe> cafes) {
        this.context = context;
        this.cafes = cafes != null ? cafes : new ArrayList<>();
    }

    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public CafeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cafe, parent, false);
        return new CafeViewHolder(view);
    }

    // Bind data to the views
    @Override
    public void onBindViewHolder(@NonNull CafeViewHolder holder, int position) {
        Cafe cafe = cafes.get(position);

        // Set the simplified details (name, location, and description)
        holder.nameTextView.setText(cafe.getName());
        holder.addressTextView.setText(cafe.getLocation());
        holder.descriptionTextView.setText(cafe.getStatus() != null ? cafe.getStatus() : "No description available");

        // Load the cafe image using Glide
        Glide.with(context)
                .load(cafe.getImageUrl())
                .placeholder(R.drawable.logo_coffee)
                .into(holder.cafeImageView);

        // Set heart button for favorite functionality
        holder.heartButton.setImageResource(cafe.isFavorite() ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
        holder.heartButton.setOnClickListener(v -> {
            boolean newFavoriteStatus = !cafe.isFavorite();
            cafe.setFavorite(newFavoriteStatus);
            holder.heartButton.setImageResource(newFavoriteStatus ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
        });

        // Set click listener for item click (navigate to CafeDetailsActivity)
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, CafeDetailsActivity.class);
            intent.putExtra("placeId", cafe.getPlaceId());
            intent.putExtra("cafeName", cafe.getName());
            intent.putExtra("cafeLocation", cafe.getLocation());
            intent.putExtra("cafeStatus", cafe.getStatus());
            intent.putExtra("cafeImageUrl", cafe.getImageUrl());

            context.startActivity(intent);
        });
    }

    // Return the size of the dataset
    @Override
    public int getItemCount() {
        return cafes.size();
    }

    // ViewHolder class to hold references to the views in each item
    static class CafeViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView addressTextView;
        TextView descriptionTextView; // For displaying the description
        ImageButton heartButton;
        ImageView cafeImageView;

        // Constructor for initializing views
        public CafeViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.cafeName);
            addressTextView = itemView.findViewById(R.id.cafeAddress);
            descriptionTextView = itemView.findViewById(R.id.cafeDescription); // Initialize description view
            heartButton = itemView.findViewById(R.id.heartButton);
            cafeImageView = itemView.findViewById(R.id.cafeImage);
        }
    }
}
