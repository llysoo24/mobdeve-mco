package com.example.mobdeves19mcogr4;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class NearbySearchResponse {
    @SerializedName("results")
    public List<PlaceResult> results;

    public static class PlaceResult {
        @SerializedName("name")
        public String name;

        @SerializedName("geometry")
        public Geometry geometry;
    }

    public static class Geometry {
        @SerializedName("location")
        public LatLng location;
    }

    public static class LatLng {
        @SerializedName("lat")
        public double lat;

        @SerializedName("lng")
        public double lng;
    }
}