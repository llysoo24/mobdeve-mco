package com.example.mobdeves19mcogr4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class CafeDetailsActivity extends AppCompatActivity {

    private TextView nameTextView;
    private TextView locationTextView;
    private TextView descriptionTextView;
    private ImageView cafeImageView;
    private TextView wifiTextView;
    private TextView quietTextView;
    private TextView groupTextView;
    private TextView customerReviewTextView;
    private TextView userNameTextView; 
    private ImageView[] stars;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe_details);

        nameTextView = findViewById(R.id.cafeNameTextView);
        locationTextView = findViewById(R.id.cafeLocationTextView);
        descriptionTextView = findViewById(R.id.cafeDescriptionTextView);
        cafeImageView = findViewById(R.id.cafeImageView);
        wifiTextView = findViewById(R.id.wifiTextView);
        quietTextView = findViewById(R.id.quietTextView);
        groupTextView = findViewById(R.id.groupTextView);
        customerReviewTextView = findViewById(R.id.customerReviewTextView);
        userNameTextView = findViewById(R.id.userNameTextView);

        stars = new ImageView[] {
                findViewById(R.id.star1),
                findViewById(R.id.star2),
                findViewById(R.id.star3),
                findViewById(R.id.star4),
                findViewById(R.id.star5)
        };

        Intent intent = getIntent();
        String cafeName = intent.getStringExtra("cafeName");
        String cafeLocation = intent.getStringExtra("cafeLocation");
        String cafeDescription = intent.getStringExtra("cafeDescription");
        String cafeImageUrl = intent.getStringExtra("cafeImageUrl");
        boolean hasWifi = intent.getBooleanExtra("cafeHasWifi", false);
        boolean isQuiet = intent.getBooleanExtra("cafeIsQuiet", false);
        boolean isGroup = intent.getBooleanExtra("cafeIsGroup", false);
        String userName = intent.getStringExtra("userName");

        nameTextView.setText(cafeName);
        locationTextView.setText(cafeLocation);
        descriptionTextView.setText(cafeDescription);

        Glide.with(this)
                .load(cafeImageUrl)
                .placeholder(R.drawable.cafe_image_1)
                .into(cafeImageView);

        wifiTextView.setText(hasWifi ? "Wifi Available" : "No Wifi");
        quietTextView.setText(isQuiet ? "Quiet Atmosphere" : "Not Quiet");
        groupTextView.setText(isGroup ? "Group-Friendly" : "Not Group-Friendly");

        userNameTextView.setText(userName != null && !userName.isEmpty() ? userName : "Anonymous");

        String customerReview = "This cafe has a great atmosphere and friendly staff!";
        customerReviewTextView.setText(customerReview);

        setStarRating(4);
    }

    private void setStarRating(int rating) {
        for (int i = 0; i < stars.length; i++) {
            if (i < rating) {
                stars[i].setImageResource(R.drawable.star_filled);
            } else {
                stars[i].setImageResource(R.drawable.star_border);
            }
        }
    }
}
