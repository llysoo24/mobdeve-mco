package com.example.mobdeves19mcogr4;

public class Cafe {
    private String name;
    private String location;
    private String description;
    private String imageUrl;
    private boolean hasWifi;
    private boolean isQuiet;
    private boolean isGroup;
    private boolean isFavorite;
    private int image;

    // Constructor
    public Cafe(String name, String location, String description, String imageUrl, String s, boolean hasWifi, boolean isQuiet, boolean isGroup, boolean b, boolean b1, int image) {
        this.name = name;
        this.location = location;
        this.description = description;
        this.imageUrl = imageUrl;
        this.hasWifi = hasWifi;
        this.isQuiet = isQuiet;
        this.isGroup = isGroup;
        this.isFavorite = isFavorite;
        this.image = image;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getDescription() {
        return description;
    }

    public boolean hasWifi() {
        return hasWifi;
    }

    public boolean isQuiet() {
        return isQuiet;
    }

    public boolean isGroup() {
        return isGroup;
    }

    public boolean isFavorite() {return isFavorite; }

    public int getImage() {return image; }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setHasWifi(boolean hasWifi) {
        this.hasWifi = hasWifi;
    }

    public void setQuiet(boolean isQuiet) {
        this.isQuiet = isQuiet;
    }

    public void setGroup(boolean isGroup) {
        this.isGroup = isGroup;
    }

    public void setFavorite(boolean isFavorite) {this.isFavorite = isFavorite;}

    public String getCafeInfo() {
        return "Name: " + name +
                "\nLocation: " + location +
                "\nDescription: " + description +
                "\nWifi: " + (hasWifi ? "Yes" : "No") +
                "\nQuiet Atmosphere: " + (isQuiet ? "Yes" : "No") +
                "\nGroup-friendly: " + (isGroup ? "Yes" : "No");
    }
}