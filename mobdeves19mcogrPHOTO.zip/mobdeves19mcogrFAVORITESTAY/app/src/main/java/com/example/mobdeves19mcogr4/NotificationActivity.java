package com.example.mobdeves19mcogr4;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.SharedPreferences;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class NotificationActivity extends AppCompatActivity {

    private RecyclerView recyclerViewNotifications;
    private NotificationAdapter notificationAdapter;
    private List<Notification> notificationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        recyclerViewNotifications = findViewById(R.id.recyclerViewNotifications);
        recyclerViewNotifications.setLayoutManager(new LinearLayoutManager(this));

        // Load notifications from SharedPreferences or other storage
        notificationList = loadNotifications();

        // Initialize the adapter with the loaded notifications
        notificationAdapter = new NotificationAdapter(notificationList);
        recyclerViewNotifications.setAdapter(notificationAdapter);
    }

    // Example: Load notifications from SharedPreferences
    private List<Notification> loadNotifications() {
        SharedPreferences sharedPreferences = getSharedPreferences("Notifications", MODE_PRIVATE);
        Map<String, ?> allNotifications = sharedPreferences.getAll();

        List<Notification> notifications = new ArrayList<>();
        for (Map.Entry<String, ?> entry : allNotifications.entrySet()) {
            String notificationJson = (String) entry.getValue();
            Notification notification = new Gson().fromJson(notificationJson, Notification.class);
            notifications.add(notification);
        }
        return notifications;
    }

    // Example: Save a notification when it's created
    public void saveNotification(Notification notification) {
        SharedPreferences sharedPreferences = getSharedPreferences("Notifications", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        String notificationJson = new Gson().toJson(notification);
        editor.putString(notification.getTimestamp(), notificationJson);
        editor.apply();

        // Reload the notifications and update the UI
        notificationList = loadNotifications();
        notificationAdapter.updateData(notificationList);
    }
}
