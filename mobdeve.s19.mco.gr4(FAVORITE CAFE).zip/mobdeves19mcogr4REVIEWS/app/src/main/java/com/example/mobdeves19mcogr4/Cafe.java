package com.example.mobdeves19mcogr4;

import android.os.Parcel;
import android.os.Parcelable;

public class Cafe implements Parcelable{
    private String name;
    private String location;
    private String description;
    private String imageUrl;
    private boolean hasWifi;
    private boolean isQuiet;
    private boolean isGroup;
    private boolean isFavorite;
    private int image;

    // Constructor
    public Cafe(String name, String location, String description, String imageUrl, String s, boolean hasWifi, boolean isQuiet, boolean isGroup, boolean b, boolean b1, int image) {
        this.name = name;
        this.location = location;
        this.description = description;
        this.imageUrl = imageUrl;
        this.hasWifi = hasWifi;
        this.isQuiet = isQuiet;
        this.isGroup = isGroup;
        this.isFavorite = isFavorite;
        this.image = image;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getDescription() {
        return description;
    }

    public boolean hasWifi() {
        return hasWifi;
    }

    public boolean isQuiet() {
        return isQuiet;
    }

    public boolean isGroup() {
        return isGroup;
    }

    public boolean isFavorite() {return isFavorite; }

    public int getImage() {return image; }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setHasWifi(boolean hasWifi) {
        this.hasWifi = hasWifi;
    }

    public void setQuiet(boolean isQuiet) {
        this.isQuiet = isQuiet;
    }

    public void setGroup(boolean isGroup) {
        this.isGroup = isGroup;
    }

    public void setFavorite(boolean isFavorite) {this.isFavorite = isFavorite;}

    public String getCafeInfo() {
        return "Name: " + name +
                "\nLocation: " + location +
                "\nDescription: " + description +
                "\nWifi: " + (hasWifi ? "Yes" : "No") +
                "\nQuiet Atmosphere: " + (isQuiet ? "Yes" : "No") +
                "\nGroup-friendly: " + (isGroup ? "Yes" : "No");
    }
    // Parcelable implementation
    protected Cafe(Parcel in) {
        name = in.readString();
        location = in.readString();
        description = in.readString();
        imageUrl = in.readString();
        hasWifi = in.readByte() != 0;
        isQuiet = in.readByte() != 0;
        isGroup = in.readByte() != 0;
        isFavorite = in.readByte() != 0;
        image = in.readInt();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(location);
        dest.writeString(description);
        dest.writeString(imageUrl);
        dest.writeByte((byte) (hasWifi ? 1 : 0));
        dest.writeByte((byte) (isQuiet ? 1 : 0));
        dest.writeByte((byte) (isGroup ? 1 : 0));
        dest.writeByte((byte) (isFavorite ? 1 : 0));
        dest.writeInt(image);
    }

    public static final Creator<Cafe> CREATOR = new Creator<Cafe>() {
        @Override
        public Cafe createFromParcel(Parcel in) {
            return new Cafe(in);
        }

        @Override
        public Cafe[] newArray(int size) {
            return new Cafe[size];
        }
    };
}