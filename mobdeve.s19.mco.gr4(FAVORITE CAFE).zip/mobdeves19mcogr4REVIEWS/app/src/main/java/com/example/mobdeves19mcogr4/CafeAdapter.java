package com.example.mobdeves19mcogr4;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CafeAdapter extends RecyclerView.Adapter<CafeAdapter.CafeViewHolder> {
    private final Context context;
    private final List<Cafe> cafes;

    public CafeAdapter(Context context, List<Cafe> cafes) {
        this.context = context;
        this.cafes = cafes != null ? cafes : new ArrayList<>();
    }

    public interface FavoriteChangeListener {
        void onFavoriteChanged(Cafe cafe);
    }

    @NonNull
    @Override
    public CafeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cafe, parent, false);
        return new CafeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CafeViewHolder holder, int position) {
        Cafe cafe = cafes.get(position);

        holder.nameTextView.setText(cafe.getName());
        holder.addressTextView.setText(cafe.getLocation());
        holder.priceRangeTextView.setText("₱₱"); // Placeholder for price range
        holder.hoursTextView.setText(R.string.open_hours); // Placeholder for hours
        holder.contactTextView.setText(R.string.contact_number); // Placeholder for contact

        holder.cafeImageView.setImageResource(cafe.getImage());

        holder.heartButton.setImageResource(cafe.isFavorite() ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
        holder.heartButton.setOnClickListener(v -> {
            // Toggle favorite status
            boolean newFavoriteStatus = !cafe.isFavorite();
            cafe.setFavorite(newFavoriteStatus);

            // Update the heart button icon
            holder.heartButton.setImageResource(newFavoriteStatus ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);

            // Optionally notify the activity/fragment that a favorite status changed
            if (context instanceof FavoriteChangeListener) {
                ((FavoriteChangeListener) context).onFavoriteChanged(cafe);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, CafeDetailsActivity.class);

            intent.putExtra("cafeName", cafe.getName());
            intent.putExtra("cafeLocation", cafe.getLocation());
            intent.putExtra("cafeDescription", cafe.getDescription());
            intent.putExtra("cafeImageUrl", cafe.getImage());
            intent.putExtra("cafeHasWifi", cafe.hasWifi());
            intent.putExtra("cafeIsQuiet", cafe.isQuiet());
            intent.putExtra("cafeIsGroup", cafe.isGroup());

            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return cafes.size();
    }

    static class CafeViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView addressTextView;
        TextView priceRangeTextView;
        TextView hoursTextView;
        TextView contactTextView;
        ImageButton heartButton;
        ImageView cafeImageView;

        public CafeViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.cafeName);
            addressTextView = itemView.findViewById(R.id.cafeAddress);
            priceRangeTextView = itemView.findViewById(R.id.cafePriceRange);
            hoursTextView = itemView.findViewById(R.id.cafeHours);
            contactTextView = itemView.findViewById(R.id.cafeContact);
            heartButton = itemView.findViewById(R.id.heartButton);
            cafeImageView = itemView.findViewById(R.id.cafeImage);
        }
    }
}
