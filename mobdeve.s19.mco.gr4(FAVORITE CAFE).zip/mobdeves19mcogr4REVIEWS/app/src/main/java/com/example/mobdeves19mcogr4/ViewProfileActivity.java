package com.example.mobdeves19mcogr4;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageView;
import java.util.ArrayList;

public class ViewProfileActivity extends AppCompatActivity {

    private TextView nameTextView;
    private TextView emailTextView;
    private Button editProfileButton;
    private LinearLayout favoritesLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        nameTextView = findViewById(R.id.nameTextView);
        emailTextView = findViewById(R.id.emailTextView);
        editProfileButton = findViewById(R.id.editProfileButton);
        favoritesLinearLayout = findViewById(R.id.favoritesLinearLayout);

        Intent intent = getIntent();
        ArrayList<Cafe> favoriteCafes = intent.getParcelableArrayListExtra("FAVORITE_CAFES");
        String userName = intent.getStringExtra("USER_NAME");
        String userEmail = intent.getStringExtra("USER_EMAIL");

        if (favoriteCafes != null && !favoriteCafes.isEmpty()) {
            favoritesLinearLayout.removeAllViews(); // Clear any previous views
            for (Cafe cafe : favoriteCafes) {
                LinearLayout cafeLayout = new LinearLayout(this);
                cafeLayout.setOrientation(LinearLayout.HORIZONTAL);
                cafeLayout.setPadding(10, 10, 10, 10);

                // ImageView for cafe image
                ImageView cafeImageView = new ImageView(this);
                cafeImageView.setLayoutParams(new LinearLayout.LayoutParams(200, 200)); // Set fixed size for images
                cafeImageView.setImageResource(cafe.getImage()); // Use the image resource
                cafeImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                cafeLayout.addView(cafeImageView); // Add image to layout

                // TextView for cafe name
                TextView cafeNameTextView = new TextView(this);
                cafeNameTextView.setText(cafe.getName()); // Display cafe name
                cafeNameTextView.setTextSize(18);
                cafeNameTextView.setPadding(20, 0, 0, 0); // Add some padding to the right of the image
                cafeLayout.addView(cafeNameTextView); // Add name to layout

                // Add the LinearLayout (cafe view) to the main layout
                favoritesLinearLayout.addView(cafeLayout);
            }
        } else {
            TextView noFavoritesText = new TextView(this);
            noFavoritesText.setText("No favorites yet!");
            favoritesLinearLayout.addView(noFavoritesText);
        }

        nameTextView.setText(userName);
        emailTextView.setText(userEmail);

        editProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("ProfileActivity", "Edit Profile button clicked!");
                Intent intent = new Intent(ViewProfileActivity.this, EditProfileActivity.class);
                startActivity(intent);
            }
        });
    }

}
