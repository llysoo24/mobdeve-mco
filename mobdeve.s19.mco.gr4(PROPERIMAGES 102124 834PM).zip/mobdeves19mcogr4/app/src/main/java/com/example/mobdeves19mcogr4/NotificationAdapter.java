package com.example.mobdeves19mcogr4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder> {
    private List<Notification> notificationList;

    // Constructor to initialize notification list
    public NotificationAdapter(List<Notification> notificationList) {
        this.notificationList = notificationList;
    }

    // Inflates the layout for each item (notification)
    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_notification, parent, false);
        return new NotificationViewHolder(view);
    }

    // Binds the data to the ViewHolder
    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder holder, int position) {
        Notification notification = notificationList.get(position);
        holder.titleTextView.setText(notification.getTitle());
        holder.messageTextView.setText(notification.getMessage());
        holder.timestampTextView.setText(notification.getTimestamp());
    }

    // Returns the size of the notification list
    @Override
    public int getItemCount() {
        return notificationList.size();
    }

    // ViewHolder class for holding the views in each item
    static class NotificationViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView messageTextView;
        TextView timestampTextView;

        // Constructor to initialize the TextViews
        public NotificationViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.notificationTitleTextView);
            messageTextView = itemView.findViewById(R.id.notificationMessageTextView);
            timestampTextView = itemView.findViewById(R.id.notificationTimestampTextView);
        }
    }
}
