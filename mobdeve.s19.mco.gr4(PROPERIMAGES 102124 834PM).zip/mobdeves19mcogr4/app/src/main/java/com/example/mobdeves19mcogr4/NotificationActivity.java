package com.example.mobdeves19mcogr4;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NotificationActivity extends AppCompatActivity {

    private RecyclerView recyclerViewNotifications;
    private NotificationAdapter notificationAdapter;
    private List<Notification> notificationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        // Initialize RecyclerView
        recyclerViewNotifications = findViewById(R.id.recyclerViewNotifications);
        recyclerViewNotifications.setLayoutManager(new LinearLayoutManager(this));

        // Hardcoded notification data
        notificationList = new ArrayList<>();
        notificationList.add(new Notification("New Cafe Added!", "Elephant Grounds Manila is now open!", "Just now"));
        notificationList.add(new Notification("Special Deal!", "20% off at Harlan + Holden Coffee this weekend!", "20m ago"));
        notificationList.add(new Notification("New Cafe Added!", "Caffe Pocofino has opened near you!", "1h ago"));
        notificationList.add(new Notification("New Cafe Added!", "Check out The Fat Seed Cafe + Roastery!", "Tue"));
        notificationList.add(new Notification("New Cafe Added!", "Try ANGKAN Coffee WCC!", "Tue"));
        notificationList.add(new Notification("New Cafe Added!", "Auro Chocolate Cafe - BGC Flagship is open now!", "Mon"));
        notificationList.add(new Notification("New Cafe Added!", "Muji Cafe has just opened!", "Mon"));
        notificationList.add(new Notification("New Cafe Added!", "% Arabica Manila Mitsukoshi BGC is now serving!", "Mon"));
        notificationList.add(new Notification("New Cafe Added!", "% Arabica Manila BGC Roastery is now available!", "Sun"));
        notificationList.add(new Notification("New Cafe Added!", "brood. Coffee - Verve Residences Tower 1 is here!", "Sun"));

        // Set adapter
        notificationAdapter = new NotificationAdapter(notificationList);
        recyclerViewNotifications.setAdapter(notificationAdapter);
    }
}
