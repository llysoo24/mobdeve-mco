package com.example.mobdeves19mcogr4;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ViewProfileActivity extends AppCompatActivity {

    private TextView nameTextView;
    private TextView bioTextView;
    private Button editProfileButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);


        // Initialize UI components
        nameTextView = findViewById(R.id.nameTextView);
        bioTextView = findViewById(R.id.bioTextView);
        editProfileButton = findViewById(R.id.editProfileButton);

        // Set hardcoded user details (replace with real user data later)
        nameTextView.setText("Jake");
        bioTextView.setText("Trying and rating coffee shops so you don't have to");

        // Set click listener for edit profile button
        editProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Log the action and start EditProfileActivity
                Log.d("ProfileActivity", "Edit Profile button clicked!");
                Intent intent = new Intent(ViewProfileActivity.this, EditProfileActivity.class);
                startActivity(intent);
            }
        });

    }
}
